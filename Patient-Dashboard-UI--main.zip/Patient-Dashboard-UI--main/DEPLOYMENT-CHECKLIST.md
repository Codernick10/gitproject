# Deployment & Verification Checklist

## Pre-Launch Setup

### 1. API Configuration (REQUIRED)
- [ ] Open `app.js` in your editor
- [ ] Navigate to line 11
- [ ] Update `baseUrl` to your actual Coalition Technologies API endpoint
- [ ] Remove placeholder URL if it exists

### 2. Authentication (If Required)
- [ ] Check if API needs authentication
- [ ] Add API key or token to fetch headers in `app.js`
- [ ] Test with Postman or curl first to verify API access

### 3. Verify API Endpoints
Make sure your API supports these endpoints:
- [ ] `GET /api/patients?name=Jessica%20Taylor` or `GET /api/patients`
- [ ] `GET /api/patients/{id}/vitals`
- [ ] `GET /api/patients/{id}/blood-pressure`
- [ ] `GET /api/patients/{id}/allergies`
- [ ] `GET /api/patients/{id}/medications`
- [ ] `GET /api/patients/{id}/diagnoses`
- [ ] `GET /api/patients/{id}/visits`

## Testing

### 4. Local Server Setup
- [ ] Choose a server method:
  - [ ] Python: `python -m http.server 8000`
  - [ ] Node.js: `node server.js` or `npx serve .`
  - [ ] PHP: `php -S localhost:8000`
  - [ ] VS Code Live Server extension

### 5. Initial Load Test
- [ ] Open browser to `http://localhost:8000` (or your port)
- [ ] Verify page loads without console errors
- [ ] Check that all sections render (Patient Info, Vitals, Chart, etc.)
- [ ] Verify blood pressure chart displays with data lines

### 6. API Connection Test
- [ ] Open DevTools (F12) → Network tab
- [ ] Refresh page
- [ ] Look for API requests being made
- [ ] Check response status codes (should be 200)
- [ ] Verify patient data populated in all sections

### 7. Fallback Data Test
- [ ] Open DevTools Console
- [ ] Run: `useFallbackData()`
- [ ] Verify dashboard populates with demo data
- [ ] Chart should show the mock blood pressure values

## Design Verification

### 8. UI Components Check
- [ ] Sidebar navigation visible on left (dark blue gradient)
- [ ] 5 nav items with icons (Dashboard, Patients, Appointments, etc.)
- [ ] Header with "Patient Dashboard" title and current date
- [ ] Patient Information card with full patient details
- [ ] 4 Vitals cards (BP, Heart Rate, Temperature, Weight)
- [ ] Blood Pressure chart with red (systolic) and blue (diastolic) lines
- [ ] 4 Info cards: Allergies, Medications, Diagnoses, Recent Visits

### 9. Color Scheme Check
- [ ] Sidebar: Dark blue (#1a365d to #2c5282)
- [ ] Accent: Light blue (#63b3ed, #4299e1)
- [ ] Background: Light gray (#f5f7fa)
- [ ] Cards: White with subtle shadow
- [ ] Text: Dark gray (#2d3748) for headers, medium (#718096) for labels
- [ ] Status colors: Green (normal), Orange (elevated/warning), Red (high)

### 10. Responsive Design Test
- [ ] Resize browser window to tablet width (~768px)
  - [ ] Sidebar collapses to icon-only mode
  - [ ] Vitals grid becomes 2 columns
  - [ ] Chart remains responsive
- [ ] Resize to mobile width (~375px)
  - [ ] Sidebar is icon-only narrow mode
  - [ ] All grids become single column
  - [ ] Header elements stack vertically

### 11. Interactivity Check
- [ ] Hover over vital cards - should lift slightly with shadow
- [ ] Hover over nav items - background highlights
- [ ] Chart tooltip - hover over data points shows values
- [ ] Chart should be smooth lines (tension: 0.4)

## Data Verification

### 12. Patient Data Display
- [ ] Name shows as "Jessica Taylor"
- [ ] Patient ID displayed
- [ ] Date of Birth formatted correctly (e.g., "Mar 15, 1985")
- [ ] Age calculated correctly
- [ ] Gender shown as "Female"
- [ ] Phone and email visible
- [ ] Primary Care Physician name displayed
- [ ] Blood type shown

### 13. Vitals Section
- [ ] Blood Pressure: Format "[systolic]/[diastolic] mmHg"
- [ ] BP Status badge: "Normal", "Elevated", or "Stage 1 Hypertension" etc.
- [ ] Heart Rate: Number with "bpm"
- [ ] Temperature: Number with "°F"
- [ ] Weight: Number with "lbs"

### 14. Blood Pressure Chart
- [ ] Shows last 12 readings
- [ ] X-axis: Dates (formatted as "Mar 15", etc.)
- [ ] Y-axis: mmHg values with label
- [ ] Red line = Systolic
- [ ] Blue line = Diastolic
- [ ] Points visible on lines
- [ ] Legend hidden (as per design) or shown as requested

### 15. Additional Data Sections
- [ ] Allergies: List of allergy names with severity
- [ ] Medications: Drug names with dosage and frequency
- [ ] Diagnoses: Condition names with diagnosis date
- [ ] Visits: Recent visit reasons/purposes with dates

## Performance

### 16. Load Time
- [ ] Page loads in < 3 seconds on fast connection
- [ ] Chart renders smoothly without lag
- [ ] No console warnings about slow resources

### 17. API Calls
- [ ] No excessive API calls (should be ~6-7 total)
- [ ] All calls succeed (200 status)
- [ ] No CORS errors in console
- [ ] Response times < 1 second each

## Final Checks

### 18. Code Quality
- [ ] No syntax errors in console
- [ ] No 404 errors for CSS/JS files
- [ ] Chart.js CDN loaded successfully
- [ ] No jQuery or unnecessary dependencies
- [ ] Clean, readable code structure

### 19. Browser-Specific
- [ ] Test in Chrome
- [ ] Test in Firefox (if required)
- [ ] Test in Safari (if required)
- [ ] All features work consistently

### 20. Submission Ready
- [ ] All files in project folder: index.html, styles.css, app.js, etc.
- [ ] API endpoint configured correctly
- [ ] README.md updated with your specific setup notes
- [ ] QUICKSTART.txt included
- [ ] Test with fallback data works as demo

---

## Quick Verification Commands

```bash
# Check files exist
ls -la

# Start server (Python)
python -m http.server 8000

# Start server (Node)
node server.js

# Open browser
# http://localhost:8000
```

## Common Issues & Quick Fixes

| Issue | Solution |
|-------|----------|
| CORS block | Use `node server.js` which adds CORS headers |
| Chart not showing | Check internet connection (Chart.js loads from CDN) |
| No data | Verify API URL in app.js line 11 |
| 404 files | Make sure you're accessing via http://localhost: not file:// |
| Styling broken | Clear browser cache (Ctrl+F5) |

---

**Status:** [ ] All checks complete - Ready for submission

**Notes:**
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________
