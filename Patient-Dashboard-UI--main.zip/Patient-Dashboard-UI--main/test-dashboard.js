/**
 * Test Script for Patient Dashboard
 * Run in browser console after loading index.html
 */

console.log('╔══════════════════════════════════════════╗');
console.log('║   Patient Dashboard Test Suite          ║');
console.log('╚══════════════════════════════════════════╝');

// Test 1: Check Chart.js loaded
console.log('\n✓ Test 1: Chart.js loaded?', typeof Chart !== 'undefined' ? '✅ PASS' : '❌ FAIL');

// Test 2: Check all elements exist
const requiredElements = [
    'patientInfo',
    'bloodPressureChart',
    'bpLatest',
    'bpStatus',
    'heartRate',
    'temperature',
    'weight',
    'allergiesList',
    'medicationsList',
    'diagnosesList',
    'visitsList',
    'currentDate'
];

let allElementsFound = true;
requiredElements.forEach(id => {
    const el = document.getElementById(id);
    if (!el) {
        console.log(`❌ Missing element: #${id}`);
        allElementsFound = false;
    }
});

if (allElementsFound) {
    console.log('✓ Test 2: All DOM elements present ✅ PASS');
} else {
    console.log('✗ Test 2: Some DOM elements missing ❌ FAIL');
}

// Test 3: Check CSS loaded
const sidebar = document.querySelector('.sidebar');
const mainContent = document.querySelector('.main-content');
if (sidebar && mainContent) {
    const sidebarStyle = window.getComputedStyle(sidebar);
    const mainStyle = window.getComputedStyle(mainContent);
    console.log('✓ Test 3: CSS loaded and applied ✅ PASS');
} else {
    console.log('✗ Test 3: CSS not properly loaded ❌ FAIL');
}

// Test 4: API Configuration
console.log('\n📋 Configuration Info:');
console.log('   API Base URL:', window.APP_CONFIG?.API_BASE_URL || 'Using default in app.js');
console.log('   Target Patient:', window.APP_CONFIG?.TARGET_PATIENT_NAME || 'Jessica Taylor');
console.log('   Fallback Mode:', window.APP_CONFIG?.USE_FALLBACK_DATA || false);

// Test 5: Manual fallback data test
console.log('\n🧪 To test with fallback data, run: useFallbackData()');
console.log('🧪 To check API status, open DevTools Network tab');

console.log('\n╔══════════════════════════════════════════╗');
console.log('║   Test complete!                        ║');
console.log('║   Check dashboard rendering above.     ║');
console.log('╚══════════════════════════════════════════╝');
