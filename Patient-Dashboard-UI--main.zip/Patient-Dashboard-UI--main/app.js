/**
 * Tech.Care Patient Dashboard
 * API: https://fedskillstest.coalitiontechnologies.workers.dev
 * Auth: Basic coalition:skills-test
 */

const API_URL  = 'https://fedskillstest.coalitiontechnologies.workers.dev';
const AUTH_HDR = 'Basic ' + btoa('coalition:skills-test');

// ── State ──────────────────────────────────────────────────────────────
let allPatients   = [];
let activePatient = null;
let bpChart       = null;

// ── Boot ───────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', initApp);

async function initApp() {
    console.log('Patient Dashboard Initializing...');
    wireSearch();
    wireTopNav();

    try {
        const res = await fetch(API_URL, { headers: { Authorization: AUTH_HDR } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        allPatients = await res.json();
    } catch (err) {
        console.warn('API unavailable, using fallback:', err.message);
        allPatients = buildFallback();
    }

    activePatient = allPatients.find(p => p.name === 'Jessica Taylor') || allPatients[0];
    renderPatientList(allPatients);
    renderDashboard(activePatient);
    
    // Ensure grid is visible
    const patientsMain = document.querySelector('.page-body');
    if (patientsMain) patientsMain.style.display = 'grid';
}

// ── Top Nav ────────────────────────────────────────────────────────────
function wireTopNav() {
    document.querySelectorAll('.tnav-item').forEach(link => {
        link.addEventListener('click', e => {
            e.preventDefault();
            const view = link.getAttribute('data-view');
            
            // Update active link
            document.querySelectorAll('.tnav-item').forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            // Handle visibility (Only the 'patients' view exists for now)
            const patientsMain = document.querySelector('.page-body');
            if (view === 'patients') {
                if (patientsMain) patientsMain.style.display = 'grid';
            } else {
                // If they click another tab, we can hide the dashboard or show a placeholder
                // For now, let's keep it visible but we could hide it if needed:
                // if (patientsMain) patientsMain.style.display = 'none';
            }
        });
    });
}

// ── Search ─────────────────────────────────────────────────────────────
function wireSearch() {
    const btn   = document.getElementById('sidebarSearchBtn');
    const bar   = document.getElementById('sidebarSearchBar');
    const input = document.getElementById('patientSearchInput');
    if (!btn || !bar || !input) return;

    btn.addEventListener('click', () => {
        bar.classList.toggle('open');
        if (bar.classList.contains('open')) {
            input.focus();
        } else {
            input.value = '';
            renderPatientList(allPatients);
        }
    });

    input.addEventListener('input', () => {
        const q = input.value.trim().toLowerCase();
        const filtered = q ? allPatients.filter(p => p.name.toLowerCase().includes(q)) : allPatients;
        renderPatientList(filtered);
    });
}

// ── Patient List ────────────────────────────────────────────────────────
function renderPatientList(patients) {
    const container = document.getElementById('patientsList');
    container.innerHTML = '';

    if (!patients.length) {
        container.innerHTML = `<div class="loading-patients" style="padding:28px 20px">No patients found.</div>`;
        return;
    }

    patients.forEach(patient => {
        const item = document.createElement('div');
        item.className = 'patient-item' + (patient.name === activePatient?.name ? ' active' : '');
        item.dataset.name = patient.name;

        // Avatar
        const avatarHTML = patient.profile_picture
            ? `<img src="${patient.profile_picture}" alt="${patient.name}" class="patient-avatar-small"
                    onerror="this.replaceWith(makeInitialsEl('${getInitials(patient.name)}'))">`
            : `<div class="patient-avatar-initials">${getInitials(patient.name)}</div>`;

        item.innerHTML = `
            <div class="patient-meta">
                ${avatarHTML}
                <div class="patient-details-mini">
                    <span class="patient-name-mini">${patient.name}</span>
                    <span class="patient-info-mini">${patient.gender || ''}${patient.age ? ', ' + patient.age : ''}</span>
                </div>
            </div>
            <button class="patient-more-btn" title="More options">···</button>
        `;

        item.addEventListener('click', e => {
            if (e.target.classList.contains('patient-more-btn')) return;
            document.querySelectorAll('.patient-item').forEach(el => el.classList.remove('active'));
            item.classList.add('active');
            activePatient = patient;
            renderDashboard(patient);
        });

        container.appendChild(item);
    });
}

// ── Full Dashboard ──────────────────────────────────────────────────────
function renderDashboard(patient) {
    renderProfileCard(patient);
    renderBPChart(patient);
    renderVitalCards(patient);
    renderDiagnosticTable(patient);
    renderLabResults(patient);
}

// ── Right Sidebar: Profile Card ─────────────────────────────────────────
function renderProfileCard(patient) {
    // Avatar
    const avatarEl = document.getElementById('patientAvatar');
    const placeholder = document.getElementById('patientAvatarPlaceholder');

    if (patient.profile_picture) {
        avatarEl.src = patient.profile_picture;
        avatarEl.style.display = 'block';
        avatarEl.onerror = () => {
            avatarEl.style.display = 'none';
            if (placeholder) {
                placeholder.textContent = getInitials(patient.name);
                placeholder.style.display = 'flex';
            }
        };
        if (placeholder) placeholder.style.display = 'none';
    } else {
        avatarEl.style.display = 'none';
        if (placeholder) {
            placeholder.textContent = getInitials(patient.name);
            placeholder.style.display = 'flex';
        }
    }

    // Name
    setText('patientName', patient.name || '—');

    // DOB
    const dob = patient.date_of_birth || patient.dateOfBirth || '';
    setText('dobValue', dob ? formatDOB(dob) : '—');

    // Gender
    setText('genderValue', patient.gender || '—');

    // Contact
    setText('phoneValue', patient.phone_number || patient.phone || '—');

    // Emergency
    const ec = patient.emergency_contact;
    let ecText = '—';
    if (typeof ec === 'string') ecText = ec;
    else if (ec && typeof ec === 'object') ecText = ec.phone || ec.name || '—';
    setText('emergencyValue', ecText);

    // Insurance
    const ins = patient.insurance_type || patient.insurance?.provider || patient.insurance || '—';
    setText('insuranceValue', typeof ins === 'string' ? ins : '—');
}

// ── Vital Cards ─────────────────────────────────────────────────────────
function renderVitalCards(patient) {
    const history = patient.diagnosis_history;
    if (!history?.length) return;
    const latest = history[0];

    // Respiratory Rate
    const rr = latest.respiratory_rate || {};
    setText('respiratoryRate', rr.value != null ? `${rr.value} bpm` : '—');
    setText('respiratoryStatus', rr.levels || 'Normal');

    // Temperature
    const temp = latest.temperature || {};
    setText('temperature', temp.value != null ? `${temp.value}°F` : '—');
    setText('temperatureStatus', temp.levels || 'Normal');

    // Heart Rate
    const hr = latest.heart_rate || {};
    setText('heartRate', hr.value != null ? `${hr.value} bpm` : '—');
    const hrStatusEl = document.getElementById('heartRateStatus');
    if (hrStatusEl) hrStatusEl.innerHTML = buildStatusHTML(hr.levels);
}

// ── BP Chart ────────────────────────────────────────────────────────────
function renderBPChart(patient) {
    const history = patient.diagnosis_history;
    if (!history?.length) return;

    const slice  = history.slice(0, 6).reverse();
    const latest = history[0];

    // Update metric numbers
    const sys = latest.blood_pressure?.systolic  || {};
    const dia = latest.blood_pressure?.diastolic || {};
    setText('systolicValue',  sys.value != null ? String(sys.value) : '—');
    setText('diastolicValue', dia.value != null ? String(dia.value) : '—');
    const sysStatusEl = document.getElementById('systolicStatus');
    const diaStatusEl = document.getElementById('diastolicStatus');
    if (sysStatusEl) sysStatusEl.innerHTML = buildStatusHTML(sys.levels);
    if (diaStatusEl) diaStatusEl.innerHTML = buildStatusHTML(dia.levels);

    // Chart
    const labels  = slice.map(h => `${h.month?.substring(0,3) || ''}, ${h.year || ''}`);
    const sysData = slice.map(h => h.blood_pressure?.systolic?.value  ?? null);
    const diaData = slice.map(h => h.blood_pressure?.diastolic?.value ?? null);

    const ctx = document.getElementById('bloodPressureChart')?.getContext('2d');
    if (!ctx) return;
    if (bpChart) bpChart.destroy();

    bpChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [
                {
                    label: 'Systolic',
                    data: sysData,
                    borderColor: '#C26EB4',
                    backgroundColor: 'rgba(194,110,180,0.12)',
                    pointBackgroundColor: '#E66FD2',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    borderWidth: 2.5,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Diastolic',
                    data: diaData,
                    borderColor: '#7E6CAB',
                    backgroundColor: 'rgba(126,108,171,0.08)',
                    pointBackgroundColor: '#8C6FE6',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    borderWidth: 2.5,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: c => `${c.dataset.label}: ${c.parsed.y} mmHg`
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    suggestedMin: 60,
                    suggestedMax: 180,
                    grid: { color: 'rgba(0,0,0,0.06)' },
                    ticks: { font: { size: 11, family: 'Manrope' }, color: '#707070' }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 11, family: 'Manrope' }, color: '#707070' }
                }
            }
        }
    });
}

// ── Diagnostic Table ─────────────────────────────────────────────────────
function renderDiagnosticTable(patient) {
    const tbody = document.getElementById('diagnosticTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const list = patient.diagnostic_list || [];
    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:#707070;padding:22px">No diagnoses recorded</td></tr>`;
        return;
    }

    list.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${item.name || '—'}</strong></td>
            <td style="color:#707070">${item.description || '—'}</td>
            <td><span class="status-badge status-${slugify(item.status)}">${item.status || '—'}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// ── Lab Results ───────────────────────────────────────────────────────────
function renderLabResults(patient) {
    const container = document.getElementById('labResultsList');
    if (!container) return;
    container.innerHTML = '';

    const results = patient.lab_results || [];
    if (!results.length) {
        container.innerHTML = `<p style="color:#707070;font-size:14px;padding:10px">No lab results available</p>`;
        return;
    }

    results.forEach(result => {
        const name = typeof result === 'string' ? result : (result.name || '—');
        const item = document.createElement('div');
        item.className = 'lab-item';
        item.innerHTML = `
            <span class="lab-name">${name}</span>
            <img src="https://fedskillstest.coalitiontechnologies.workers.dev/assets/download_FILL0_wght300_GRAD0_opsz24.svg"
                 alt="Download" class="download-icon"
                 onerror="this.outerHTML='<span style=color:#ccc;font-size:18px>↓</span>'">
        `;
        container.appendChild(item);
    });
}

// ── Helpers ───────────────────────────────────────────────────────────────
function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

function formatDOB(dateStr) {
    try {
        return new Date(dateStr).toLocaleDateString('en-US', {
            year: 'numeric', month: 'long', day: 'numeric'
        });
    } catch { return dateStr; }
}

function getInitials(name = '') {
    return name.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
}

function slugify(str = '') {
    return str.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
}

function buildStatusHTML(levels) {
    if (!levels) return '';
    const lower  = levels.toLowerCase();
    const isUp   = lower.includes('higher');
    const isDown = lower.includes('lower');
    const base   = 'https://fedskillstest.coalitiontechnologies.workers.dev/assets/';
    let arrow = '';
    if (isUp)   arrow = `<img src="${base}ArrowUp.svg"   alt="↑" style="width:13px;vertical-align:middle">`;
    if (isDown) arrow = `<img src="${base}ArrowDown.svg" alt="↓" style="width:13px;vertical-align:middle">`;
    return `${arrow} ${levels}`;
}

window.makeInitialsEl = function(initials) {
    const div = document.createElement('div');
    div.className = 'patient-avatar-initials';
    div.textContent = initials;
    return div;
};

// ── Fallback Dataset ──────────────────────────────────────────────────────
function buildFallback() {
    function defaultHistory() {
        const months = ['March','February','January','December','November','October'];
        const years  = [2024,2024,2024,2023,2023,2023];
        return months.map((m,i) => ({
            month: m, year: years[i],
            blood_pressure: { systolic:{value:120,levels:'Normal'}, diastolic:{value:80,levels:'Normal'} },
            respiratory_rate: {value:18,levels:'Normal'},
            temperature:      {value:98.6,levels:'Normal'},
            heart_rate:       {value:72,levels:'Normal'}
        }));
    }

    const jessicaHistory = [
        {month:'October', year:2023,  sys:120,dia:80,  rr:20,temp:98.6,hr:78,sysLvl:'Higher than Average',diaLvl:'Lower than Average',rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Lower than Average'},
        {month:'November',year:2023,  sys:160,dia:78,  rr:19,temp:98.4,hr:76,sysLvl:'Higher than Average',diaLvl:'Lower than Average',rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Lower than Average'},
        {month:'December',year:2023,  sys:150,dia:100, rr:22,temp:99.0,hr:80,sysLvl:'Higher than Average',diaLvl:'Higher than Average',rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Normal'},
        {month:'January', year:2024,  sys:130,dia:85,  rr:18,temp:98.6,hr:75,sysLvl:'Higher than Average',diaLvl:'Normal',           rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Lower than Average'},
        {month:'February',year:2024,  sys:155,dia:92,  rr:21,temp:98.8,hr:79,sysLvl:'Higher than Average',diaLvl:'Higher than Average',rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Normal'},
        {month:'March',   year:2024,  sys:160,dia:78,  rr:20,temp:98.6,hr:72,sysLvl:'Higher than Average',diaLvl:'Lower than Average',rrLvl:'Normal',tempLvl:'Normal',hrLvl:'Lower than Average'},
    ].reverse().map(e => ({
        month:e.month, year:e.year,
        blood_pressure: {systolic:{value:e.sys,levels:e.sysLvl},diastolic:{value:e.dia,levels:e.diaLvl}},
        respiratory_rate:{value:e.rr,levels:e.rrLvl},
        temperature:{value:e.temp,levels:e.tempLvl},
        heart_rate:{value:e.hr,levels:e.hrLvl}
    }));

    return [
        { name:'Emily Williams',   gender:'Female',age:18, profile_picture:'https://randomuser.me/api/portraits/women/10.jpg', date_of_birth:'2006-04-15', phone_number:'(415) 555-1001', emergency_contact:'(415) 555-1002', insurance_type:'Sunrise Health Assurance', diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Ryan Johnson',     gender:'Male',  age:45, profile_picture:'https://randomuser.me/api/portraits/men/22.jpg',   date_of_birth:'1979-07-12', phone_number:'(415) 555-2002', emergency_contact:'(415) 555-2003', insurance_type:'Blue Cross Blue Shield',    diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Brandon Mitchell', gender:'Male',  age:56, profile_picture:'https://randomuser.me/api/portraits/men/45.jpg',   date_of_birth:'1968-02-28', phone_number:'(415) 555-3003', emergency_contact:'(415) 555-3004', insurance_type:'Aetna Health',              diagnosis_history:defaultHistory(), diagnostic_list:[{name:'Type 2 Diabetes',description:'Insulin resistance',status:'Active'}], lab_results:['Blood Tests','X-Rays'] },
        {
            name:'Jessica Taylor', gender:'Female',age:28,
            profile_picture:'https://fedskillstest.coalitiontechnologies.workers.dev/assets/senior-woman-doctor-and-portrait-smile-for-health-2023-11-27-05-18-16-utc.png',
            date_of_birth:'1996-08-23', phone_number:'(415) 555-1234', emergency_contact:'(415) 555-5678',
            insurance_type:'Sunrise Health Assurance',
            diagnosis_history: jessicaHistory,
            diagnostic_list:[
                {name:'Hypertension',   description:'Chronic high blood pressure',                status:'Under Observation'},
                {name:'Type 2 Diabetes',description:'Insulin resistance and elevated blood sugar', status:'Cured'},
                {name:'Asthma',         description:'Recurrent episodes of bronchial constriction',status:'Inactive'}
            ],
            lab_results:['Blood Tests','CT Scans','Radiology Reports','X-Rays','Urine Test']
        },
        { name:'Samantha Johnson', gender:'Female',age:56, profile_picture:'https://randomuser.me/api/portraits/women/55.jpg', date_of_birth:'1968-11-05', phone_number:'(415) 555-4004', emergency_contact:'(415) 555-4005', insurance_type:'United Healthcare', diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Ashley Martinez',  gender:'Female',age:54, profile_picture:'https://randomuser.me/api/portraits/women/62.jpg', date_of_birth:'1970-03-19', phone_number:'(415) 555-5005', emergency_contact:'(415) 555-5006', insurance_type:'Cigna Health',       diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Olivia Brown',     gender:'Female',age:32, profile_picture:'https://randomuser.me/api/portraits/women/71.jpg', date_of_birth:'1992-06-14', phone_number:'(415) 555-6006', emergency_contact:'(415) 555-6007', insurance_type:'Aetna Health',       diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Tyler Davis',      gender:'Male',  age:19, profile_picture:'https://randomuser.me/api/portraits/men/31.jpg',   date_of_birth:'2005-09-22', phone_number:'(415) 555-7007', emergency_contact:'(415) 555-7008', insurance_type:'Medicaid',           diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Kevin Anderson',   gender:'Male',  age:30, profile_picture:'https://randomuser.me/api/portraits/men/52.jpg',   date_of_birth:'1994-12-01', phone_number:'(415) 555-8008', emergency_contact:'(415) 555-8009', insurance_type:'Blue Cross Blue Shield', diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Dylan Thompson',   gender:'Male',  age:56, profile_picture:'https://randomuser.me/api/portraits/men/61.jpg',   date_of_birth:'1968-05-30', phone_number:'(415) 555-9009', emergency_contact:'(415) 555-9010', insurance_type:'Humana',            diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Nathan Evans',     gender:'Male',  age:58, profile_picture:'https://randomuser.me/api/portraits/men/73.jpg',   date_of_birth:'1966-01-17', phone_number:'(415) 555-1010', emergency_contact:'(415) 555-1011', insurance_type:'Medicare',          diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
        { name:'Mike Nolan',       gender:'Male',  age:31, profile_picture:'https://randomuser.me/api/portraits/men/84.jpg',   date_of_birth:'1993-08-08', phone_number:'(415) 555-1111', emergency_contact:'(415) 555-1112', insurance_type:'Cigna Health',      diagnosis_history:defaultHistory(), diagnostic_list:[], lab_results:[] },
    ];
}
