// Configuration file for the Patient Dashboard
// Update these values according to your API setup

window.APP_CONFIG = {
    // API Base URL - Coalition Technologies Skills Test API
    API_BASE_URL: 'https://fedskillstest.coalitiontechnologies.workers.dev',

    // API Authentication - Basic Auth
    API_USERNAME: 'coalition',
    API_PASSWORD: 'skills-test',
    // Note: App uses Basic Auth automatically with these credentials

    // Target patient to display
    TARGET_PATIENT_NAME: 'Jessica Taylor',

    // Chart settings
    CHART_MAX_READINGS: 12,

    // Feature flags
    USE_FALLBACK_DATA: false, // Set to true to use demo data instead of API
    ENABLE_CHART_ANIMATION: true,
    DEBUG_MODE: true, // Set to true to see console logs

    // API Endpoints configuration
    ENDPOINTS: {
        // Single endpoint that returns all patient data
        PATIENTS: '/'
    },

    // Fallback demo data flag (if API unavailable)
    // The app will automatically use fallback data if API fails
};
